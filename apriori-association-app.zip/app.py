import pandas as pd
import streamlit as st
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules
import matplotlib.pyplot as plt
import networkx as nx

st.set_page_config(layout="wide")
st.title("🛒 Apriori Association Rules – Streamlit App")

uploaded = st.file_uploader("Upload CSV with transactions (comma-separated)", type="csv")
min_sup = st.slider("Min Support", 0.0, 0.1, 0.02, 0.005)
min_conf = st.slider("Min Confidence", 0.0, 1.0, 0.3, 0.05)

def load_transactions(uploaded):
    raw = uploaded.read().decode("utf-8").splitlines()
    return [[item.strip() for item in line.split(",") if item.strip()] for line in raw]

if uploaded:
    txns = load_transactions(uploaded)
    te = TransactionEncoder()
    df_enc = pd.DataFrame(te.fit_transform(txns), columns=te.columns_)
    fi = apriori(df_enc, min_support=min_sup, use_colnames=True)
    rules = association_rules(fi, metric="confidence", min_threshold=min_conf)
    rules['antecedents'] = rules['antecedents'].apply(lambda x: ", ".join(list(x)))
    rules['consequents'] = rules['consequents'].apply(lambda x: ", ".join(list(x)))

    st.success("Data processed successfully!")
    st.subheader("Top Frequent Itemsets")
    st.dataframe(fi.sort_values("support", ascending=False).head(10))
    st.subheader("Top Association Rules")
    st.dataframe(rules[['antecedents','consequents','support','confidence','lift']].head(10))

    csv = rules.to_csv(index=False).encode('utf-8')
    st.download_button("Download CSV", csv, "association_rules.csv", "text/csv")

    # Plot lift
    st.subheader("Lift Plot (Top 10)")
    top = rules.sort_values("lift", ascending=False).head(10)
    fig, ax = plt.subplots()
    ax.barh(top['antecedents'] + " → " + top['consequents'], top['lift'])
    ax.set_xlabel("Lift")
    st.pyplot(fig)

    # Network graph
    st.subheader("Association Rules Network")
    G = nx.DiGraph()
    for _, r in top.iterrows():
        G.add_edge(r['antecedents'], r['consequents'])
    plt.figure(figsize=(10,6))
    pos = nx.spring_layout(G)
    nx.draw(G, pos, with_labels=True, node_size=2000, node_color="lightblue")
    st.pyplot(plt.gcf())
