# 🛒 Ứng dụng Khai thác Luật Kết hợp với Thuật toán Apriori

Ứng dụng Streamlit để khai thác Frequent Itemsets và Association Rules từ dữ liệu giao dịch.

## Cách chạy
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Dữ liệu CSV mẫu
Xem file `transactions_sample.csv` (mỗi dòng là một giao dịch, items phân cách bằng dấu phẩy).
